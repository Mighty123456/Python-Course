from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import os

# Auto detect chromedriver
current_path = os.path.dirname(os.path.abspath(__file__))
driver_path = os.path.join(current_path, "chromedriver.exe")

service = Service(driver_path)
driver = webdriver.Chrome(service=service)

driver.get("https://www.facebook.com/")
driver.maximize_window()
time.sleep(3)

# --- LOGIN ---
email = driver.find_element(By.ID, "email")
password = driver.find_element(By.ID, "pass")

email.send_keys("your_email_here")
password.send_keys("your_password_here")
password.send_keys(Keys.ENTER)

time.sleep(5)

# --- CREATE POST ---
post_area = driver.find_element(By.XPATH, "//span[contains(text(),'on your mind')]")
post_area.click()

time.sleep(3)

textarea = driver.find_element(By.XPATH, "//div[@aria-label='Create a post']//div[@role='textbox']")
textarea.send_keys("This is an automated blog post created using Selenium 🤖")

time.sleep(2)

# --- POST BUTTON ---
post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
post_button.click()

time.sleep(5)
driver.quit()
