# Jenkins Setup & Debugging Experience

## Step-by-Step Jenkins Installation on AWS EC2

```bash
# 1. Install Java 17 (Required by Jenkins)
sudo yum update -y
sudo dnf install java-17-amazon-corretto -y

# 2. Add Jenkins Repository and Key
sudo wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo
sudo rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io-2023.key

# 3. Install and Start Jenkins
sudo dnf install jenkins -y
sudo systemctl enable --now jenkins

# 4. Give Jenkins user Docker permissions
sudo usermod -aG docker jenkins
sudo systemctl restart jenkins
```

---

## Troubleshooting Log & Common Challenges

### Challenge 1: Permission Denied running Docker inside Jenkins
- **Symptom**: Pipeline stage failed at `docker build` with `permission denied while trying to connect to the Docker daemon socket`.
- **Solution**: Added `jenkins` user to `docker` system group: `sudo usermod -aG docker jenkins` and restarted Jenkins (`sudo systemctl restart jenkins`).

### Challenge 2: GitHub Webhook HTTP 403 Forbidden
- **Symptom**: GitHub webhook delivered payload but Jenkins returned 403.
- **Solution**: Installed the **GitHub Plugin** in Jenkins and checked "GitHub hook trigger for GITScm polling" in Pipeline Configuration.

### Challenge 3: Environment Variable Management
- **Symptom**: Frontend container could not locate Flask API URL.
- **Solution**: Defined `environment { BACKEND_URL = 'http://localhost:5000' }` directly inside `Jenkinsfile.frontend`.
