# Jenkins CI/CD Pipeline Assignment

**Repository Link**: https://github.com/Mighty123456/Python-Course

This project demonstrates automated CI/CD pipelines using **Jenkins** running on an **AWS EC2 Instance** (Amazon Linux 2023). On every GitHub commit, webhooks trigger Jenkins to automatically pull code, run unit tests, build Docker containers, and deploy the microservices.

---

## 🛠 Project Structure

```
Jenkins_CICD_Assignment/
├── Jenkinsfile.backend        # Jenkins Declarative Pipeline for Flask REST API
├── Jenkinsfile.frontend       # Jenkins Declarative Pipeline for Express Frontend
├── backend/
│   ├── app.py                 # Flask application
│   ├── test_app.py            # Unit test suite for test pipeline stage
│   ├── Dockerfile             # Container configuration
│   └── requirements.txt
├── frontend/
│   ├── server.js              # Express web application
│   ├── package.json           # Includes test runner script
│   ├── Dockerfile             # Container configuration
│   └── views/index.ejs
├── screenshots/               # Real Jenkins & EC2 deployment proof
└── README.md
```

---

## ⚙️ Security Group Configuration (AWS EC2)

The EC2 instance hosting Jenkins and the applications configured with the following Inbound Rules:

| Port Range | Protocol | Source | Purpose |
|------------|----------|--------|---------|
| 22 | TCP | 0.0.0.0/0 | SSH Administration |
| 8080 | TCP | 0.0.0.0/0 | Jenkins Web UI |
| 3000 | TCP | 0.0.0.0/0 | Express Frontend Web Application |
| 5000 | TCP | 0.0.0.0/0 | Flask REST API Service |

---

## 🔗 GitHub Webhook Configuration

1. In GitHub Repository: **Settings → Webhooks → Add webhook**.
2. **Payload URL**: `http://<EC2-PUBLIC-IP>:8080/github-webhook/`
3. **Content type**: `application/json`
4. **Trigger**: *Just the push event*.

---

## 🔄 Jenkins Pipeline Stages

Each `Jenkinsfile` executes the following automated pipeline stages:

1. **Checkout Code**: Clones the latest commit from `main` branch.
2. **Install Dependencies**: Sets up Python venv or installs npm packages.
3. **Run Unit Tests**: Executes `unittest` (Backend) and `npm test` (Frontend).
4. **Build & Deploy Service**: Builds Docker image and starts container on target ports (`5000` & `3000`).
